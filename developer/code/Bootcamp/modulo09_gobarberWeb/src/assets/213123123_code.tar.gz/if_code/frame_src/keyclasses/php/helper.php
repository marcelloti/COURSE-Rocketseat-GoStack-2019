<?php
/**
  KeyClass\Helper
*/

namespace KeyClass;

/**
  KeyClass for handling helpers

  @package KeyClass\Helper

  @author Marcello Costa
 */
class Helper{
}