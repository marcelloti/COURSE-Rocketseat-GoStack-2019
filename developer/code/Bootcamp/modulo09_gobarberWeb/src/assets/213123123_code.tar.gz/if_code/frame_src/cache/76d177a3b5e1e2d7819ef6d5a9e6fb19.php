<?php {     $componentsViewConverted35fd46ade49591f0093e4965680b67b1=unserialize(stripslashes('a:1:{i:0;s:5:\"title\";}'));       $componentsDefined35fd46ade49591f0093e4965680b67b1=array();      global $kernelspace;      $componentsBag=$kernelspace->getVariable('componentsBag', 'insiderFrameworkSystem');     foreach ($componentsViewConverted35fd46ade49591f0093e4965680b67b1 as $key => $id) {        if (isset($componentsBag[$id])) {           $defaultState=$componentsBag[$id]['states'][$componentsBag[$id]['defaultstate']];           $stateclassdjson=\KeyClass\Registry::getComponentRegistryData(null, $defaultState['class'], 'start');           $componentsDefined35fd46ade49591f0093e4965680b67b1[]=array(               'id' => $id,               'state' => $defaultState,               'directoryClass' => $stateclassdjson['directory']           );        }        else {            $componentRecovered=\KeyClass\Registry::getComponentViewData($id,'start');            if ($componentRecovered !== false) {                $componentsDefined35fd46ade49591f0093e4965680b67b1[]=$componentRecovered;            }            else {                throw new \Exception('Error retrieving component data '.$id);            }         }     }      $viewBag = $kernelspace->getVariable('viewBag', 'insiderFrameworkSystem');     foreach($componentsDefined35fd46ade49591f0093e4965680b67b1 as $component) {         $props=serialize($component['state']['props']);         \KeyClass\FileTree::requireOnceFile(INSTALL_DIR.DIRECTORY_SEPARATOR.$component['directoryClass'].DIRECTORY_SEPARATOR.$component['state']['class'].'.php');         $n=$component['state']['class'];         $n='\Sagacious\SgsComponent\\'.$n;         ${$component['id']}=new $n($props);     }     if (!function_exists('getValueFromViewBag')) {        \KeyClass\FileTree::requireOnceFile(INSTALL_DIR.DIRECTORY_SEPARATOR.'frame_src'.DIRECTORY_SEPARATOR.'modules'.DIRECTORY_SEPARATOR.'php'.DIRECTORY_SEPARATOR.'Sagacious'.DIRECTORY_SEPARATOR.'functions.php');     } } if (DEBUG_BAR == true) {    $timer = $kernelspace->getVariable('timer', 'insiderFrameworkSystem');    $timer->debugBar('render'); }?>
<!DOCTYPE HTML>
<html>
    <head>
        
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo REQUESTED_URL; ?>/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo REQUESTED_URL; ?>/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo REQUESTED_URL; ?>/favicon-16x16.png">
        <link rel="manifest" href="<?php echo REQUESTED_URL; ?>/site.webmanifest">
        <link rel="mask-icon" href="<?php echo REQUESTED_URL; ?>/safari-pinned-tab.svg" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">
        
        
        <meta charset="<?php echo ENCODE; ?>"/>
        
        
        <?php $title->EchoCode(); ?>
        
        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/moment.js/2.22.1/moment-with-locales.min.js'></script>
        <script>
            moment.locale('<?php echo LINGUAS; ?>');
        </script>

        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/js_only_insiderframework.js'></script>

        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/jQuery/3.3.1/jquery-3.3.1.min.js'></script>

        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/jquery_insiderframework.js'></script>

        <?php
          if (DEBUG){
        ?>
            
            <link rel="stylesheet" href='<?php echo REQUESTED_URL; ?>/packs/sys/assets/css/debug.css' />
        <?php
          }
        ?>

        <style>
            #mcontent{
                text-align: center;
                padding-top: 50px;
                font-weight: bold;
                font-size: 1.1em;
                font-family: Verdana;
            }
            #descapp{
                font-size: 20px;
            }
        </style>
        <meta charset="<?php echo ENCODE; ?>"/>

        
        <?php 
                            global $kernelspace;
                            $injectedScripts = $kernelspace->getVariable("injectedScripts", "insiderFrameworkSystem");
                            echo $injectedScripts; ?>
        <?php 
                            global $kernelspace;
                            $injectedCss = $kernelspace->getVariable("injectedCss", "insiderFrameworkSystem");
                            echo $injectedCss; ?>

        
        
<style>
    .grey{
        color: #777;
    }
    #logo{
        width: 96px;
        margin-bottom: 10px;
    }
</style>

    </head>

    <body>
        <div id='mcontent'>
            <div>
                
                
    <br/><br/>
    <span style="font-size: 14px;">
        <div style="width: 100%;">
            <div>
                <img id='logo' src='android-chrome-192x192.png' /><br/>
                <span class="grey">Welcome to</span> <h1>Insider Framework</h1>
            </div>
            <br/><br/>

            <span style="font-size: 14px; color: #2C89A0">
    <u>Database model output example:</u>
    <div style="width: 100%;">
        <br/>
        <?php
            foreach($viewBag['ReturnOfModel'] as $key => $value){
                echo "<div>".$key.": ".$value."</div>";
            }
        ?>
        <br/>
    </div>
</span>

            <br/>
            <span class="grey">Try to access the url "/test" to see route rules in action</span>
        </div>
    </span>

            </div>
        </div>

        
        <?php 
                            global $kernelspace;
                            $injectedHtml = $kernelspace->getVariable("injectedHtml", "insiderFrameworkSystem");
                            echo $injectedHtml; ?>
        
        
        
    </body>
</html>
