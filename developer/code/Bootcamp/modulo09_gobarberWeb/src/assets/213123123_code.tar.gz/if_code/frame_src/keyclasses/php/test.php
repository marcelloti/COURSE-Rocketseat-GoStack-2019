<?php
/**
  KeyClass\Test
*/

namespace KeyClass;

/**
   KeyClass for classes of tests

   @package KeyClass\Test

   @author Marcello Costa
*/
class Test{

}
