# Insider Framework

Insider Framework is a web framework, initially written in the PHP language.


You can run it in a container with these steps:

1- git clone https://github.com/InsiderTI/InsiderFramework.git

2- cd InsiderFramework

3- docker-compose -p it up -d

4- Go to http://localhost
