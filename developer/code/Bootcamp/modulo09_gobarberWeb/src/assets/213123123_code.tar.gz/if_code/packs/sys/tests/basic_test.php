<?php
// Namespace relativo ao pack do controller
namespace Controllers\sys;

// Classe responsável por testes básico do pack sys
class Basic_Test extends \KeyClass\Test{
    public function init() {
        
    }
}