<?php {     $componentsViewConverted9addfcd94c5ddeb51acf6fdee42b100d=unserialize(stripslashes('a:1:{i:0;s:5:\"title\";}'));       $componentsDefined9addfcd94c5ddeb51acf6fdee42b100d=array();      global $kernelspace;      $componentsBag=$kernelspace->getVariable('componentsBag', 'insiderFrameworkSystem');     foreach ($componentsViewConverted9addfcd94c5ddeb51acf6fdee42b100d as $key => $id) {        if (isset($componentsBag[$id])) {           $defaultState=$componentsBag[$id]['states'][$componentsBag[$id]['defaultstate']];           $stateclassdjson=\KeyClass\Registry::getComponentRegistryData(null, $defaultState['class'], 'sys');           $componentsDefined9addfcd94c5ddeb51acf6fdee42b100d[]=array(               'id' => $id,               'state' => $defaultState,               'directoryClass' => $stateclassdjson['directory']           );        }        else {            $componentRecovered=\KeyClass\Registry::getComponentViewData($id,'sys');            if ($componentRecovered !== false) {                $componentsDefined9addfcd94c5ddeb51acf6fdee42b100d[]=$componentRecovered;            }            else {                throw new \Exception('Error retrieving component data '.$id);            }         }     }      $viewBag = $kernelspace->getVariable('viewBag', 'insiderFrameworkSystem');     foreach($componentsDefined9addfcd94c5ddeb51acf6fdee42b100d as $component) {         $props=serialize($component['state']['props']);         \KeyClass\FileTree::requireOnceFile(INSTALL_DIR.DIRECTORY_SEPARATOR.$component['directoryClass'].DIRECTORY_SEPARATOR.$component['state']['class'].'.php');         $n=$component['state']['class'];         $n='\Sagacious\SgsComponent\\'.$n;         ${$component['id']}=new $n($props);     }     if (!function_exists('getValueFromViewBag')) {        \KeyClass\FileTree::requireOnceFile(INSTALL_DIR.DIRECTORY_SEPARATOR.'frame_src'.DIRECTORY_SEPARATOR.'modules'.DIRECTORY_SEPARATOR.'php'.DIRECTORY_SEPARATOR.'Sagacious'.DIRECTORY_SEPARATOR.'functions.php');     } } if (DEBUG_BAR == true) {    $timer = $kernelspace->getVariable('timer', 'insiderFrameworkSystem');    $timer->debugBar('render'); }?>
<html>
    <head>
        
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo REQUESTED_URL; ?>/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo REQUESTED_URL; ?>/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo REQUESTED_URL; ?>/favicon-16x16.png">
        <link rel="manifest" href="<?php echo REQUESTED_URL; ?>/site.webmanifest">
        <link rel="mask-icon" href="<?php echo REQUESTED_URL; ?>/safari-pinned-tab.svg" color="#5bbad5">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="theme-color" content="#ffffff">
        
        
        <meta charset="<?php echo ENCODE; ?>"/>
        <?php $title->EchoCode(); ?>
        
        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/moment.js/2.22.1/moment-with-locales.min.js'></script>
        <script>
            moment.locale('<?php echo LINGUAS; ?>');
        </script>

        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/js_only_insiderframework.js'></script>

        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/jQuery/3.3.1/jquery-3.3.1.min.js'></script>

        
        <script type='text/javascript' src='<?php echo REQUESTED_URL; ?>/packs/sys/assets/js/jquery_insiderframework.js'></script>

        <?php
          if (DEBUG){
        ?>
            
            <link rel="stylesheet" href='<?php echo REQUESTED_URL; ?>/packs/sys/assets/css/debug.css' />
        <?php
          }
        ?>
    </head>
    <body style="overflow: hidden;">
        <div style='text-align: center; z-index: 999; background: #fff; position: absolute; height: 100%; width: 100%;'>
            
            
<div id="all" unselectable='on' onselectstart='return false;' onmousedown='return false;'>
    <br><br><br>
    <?php
        $error404Title = \KeyClass\I10n::getTranslate("Error 404", "pack/sys");
        $error404Msg = \KeyClass\I10n::getTranslate("Page not found", "pack/sys");
        $routeText = \KeyClass\I10n::getTranslate("Route", "pack/sys");
    ?>
    <h1 style='font-weight:bold;text-shadow: 4px -4rpx grey;'><?php echo $error404Title;?></h1>
    <br/>
    <h4 style='color: #777;'><?php echo $routeText.": ".getValueFromViewBag('originalUrlRequested'); ?></h4>
    <br/>
    <h2><?php echo $error404Msg;?></h2>
    <div class="genericerror"></div>
</div>

        </div>
        
        
        <?php 
                            global $kernelspace;
                            $injectedHtml = $kernelspace->getVariable("injectedHtml", "insiderFrameworkSystem");
                            echo $injectedHtml; ?>
    </body>
</html>
